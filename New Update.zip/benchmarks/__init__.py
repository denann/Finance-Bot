"""Offline synthetic performance benchmarks."""
